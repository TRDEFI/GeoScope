import { useState } from 'react'
import { Button } from './ui/button'
import { Card, CardContent, CardHeader, CardTitle } from './ui/card'
import { Separator } from './ui/separator'
import { Badge } from './ui/badge'
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from './ui/collapsible'
import { MapPin, Zap, TrendingUp, Users, Building, AlertCircle, Target, CheckCircle, Globe, Lock, ChevronDown, Crown, ExternalLink } from 'lucide-react'
import { toast } from 'sonner'
import { SelectedArea } from '../App'
import { User } from '../types/auth'
import LanguageSelector from './LanguageSelector'
import { supabase } from '../lib/supabase'

interface AnalysisPanelProps {
  selectedArea: SelectedArea | null
  analysis: string | null
  setAnalysis: (analysis: string | null) => void
  isAnalyzing: boolean
  setIsAnalyzing: (analyzing: boolean) => void
  user: User | null
  selectedLanguage: string
  onLanguageChange: (language: string) => void
}

const AnalysisPanel = ({ 
  selectedArea, 
  analysis, 
  setAnalysis, 
  isAnalyzing, 
  setIsAnalyzing,
  user,
  selectedLanguage,
  onLanguageChange
}: AnalysisPanelProps) => {
  const [isPremiumFeaturesOpen, setIsPremiumFeaturesOpen] = useState(false)
  const [isDataServicesOpen, setIsDataServicesOpen] = useState(false)

  console.log('AnalysisPanel rendered with:', { selectedArea, analysis, isAnalyzing, user, selectedLanguage })

  const translations = {
    en: {
      businessAnalysis: "Business Analysis",
      areaSelected: "Area Selected",
      searchesUsed: "searches used (resets every 15 days)",
      authRequired: "Authentication Required",
      authRequiredText: "Please sign in to access business analysis features",
      noAreaSelected: "No Area Selected",
      noAreaSelectedText: "Click \"How to Select Area\" to get started with your business analysis",
      readyToAnalyze: "Ready to Analyze",
      readyToAnalyzeText: "Get comprehensive AI-powered business insights for your selected area",
      searchLimitReached: "Search limit reached. Upgrade to continue analyzing.",
      analyzeOpportunities: "Analyze Business Opportunities",
      analyzingLocation: "🔍 Analyzing Location",
      analyzingText: "Our AI is processing demographic data, market trends, and business opportunities...",
      analyzingSteps: [
        "• Analyzing geographic data",
        "• Processing market trends",
        "• Identifying opportunities"
      ],
      analysisResults: "Analysis Results",
      premiumFeatures: "Premium Features",
      dataServices: "Data Services",
      premiumReport: "Get Premium Detailed Report",
      premiumReportText: "15+ pages with charts, competitor analysis, and revenue projections",
      downloadPremiumReport: "Download Premium Report ($5)",
      reAnalyze: "🔄 Re-analyze",
      clear: "🗑️ Clear",
      contactForAccess: "Contact info@trdefi.com for access"
    },
    de: {
      businessAnalysis: "Geschäftsanalyse",
      areaSelected: "Gebiet Ausgewählt",
      searchesUsed: "Suchvorgänge verwendet (wird alle 15 Tage zurückgesetzt)",
      authRequired: "Authentifizierung Erforderlich",
      authRequiredText: "Bitte melden Sie sich an, um auf Geschäftsanalysefunktionen zuzugreifen",
      noAreaSelected: "Kein Gebiet Ausgewählt",
      noAreaSelectedText: "Klicken Sie auf \"Bereich auswählen\" um mit Ihrer Geschäftsanalyse zu beginnen",
      readyToAnalyze: "Bereit zur Analyse",
      readyToAnalyzeText: "Erhalten Sie umfassende KI-gestützte Geschäftseinblicke für Ihr ausgewähltes Gebiet",
      searchLimitReached: "Suchlimit erreicht. Aktualisieren Sie, um weiter zu analysieren.",
      analyzeOpportunities: "Geschäftsmöglichkeiten Analysieren",
      analyzingLocation: "🔍 Standort Analysieren",
      analyzingText: "Unsere KI verarbeitet demografische Daten, Markttrends und Geschäftsmöglichkeiten...",
      analyzingSteps: [
        "• Geografische Daten analysieren",
        "• Markttrends verarbeiten",
        "• Möglichkeiten identifizieren"
      ],
      analysisResults: "Analyseergebnisse",
      premiumFeatures: "Premium-Funktionen",
      dataServices: "Datendienste",
      premiumReport: "Premium-Detailbericht Erhalten",
      premiumReportText: "15+ Seiten mit Diagrammen, Wettbewerbsanalyse und Umsatzprognosen",
      downloadPremiumReport: "Premium-Bericht Herunterladen ($5)",
      reAnalyze: "🔄 Erneut Analysieren",
      clear: "🗑️ Löschen",
      contactForAccess: "Kontakt info@trdefi.com für Zugang"
    },
    tr: {
      businessAnalysis: "İş Analizi",
      areaSelected: "Alan Seçildi",
      searchesUsed: "arama kullanıldı (her 15 günde sıfırlanır)",
      authRequired: "Kimlik Doğrulama Gerekli",
      authRequiredText: "İş analizi özelliklerine erişmek için lütfen giriş yapın",
      noAreaSelected: "Alan Seçilmedi",
      noAreaSelectedText: "İş analizinize başlamak için \"Alan Nasıl Seçilir\"e tıklayın",
      readyToAnalyze: "Analiz İçin Hazır",
      readyToAnalyzeText: "Seçtiğiniz alan için kapsamlı AI destekli iş öngörüleri edinin",
      searchLimitReached: "Arama limiti doldu. Analize devam etmek için yükseltin.",
      analyzeOpportunities: "İş Fırsatlarını Analiz Et",
      analyzingLocation: "🔍 Konum Analiz Ediliyor",
      analyzingText: "AI'mız demografik veriler, pazar trendleri ve iş fırsatlarını işliyor...",
      analyzingSteps: [
        "• Coğrafi veriler analiz ediliyor",
        "• Pazar trendleri işleniyor",
        "• Fırsatlar belirleniyor"
      ],
      analysisResults: "Analiz Sonuçları",
      premiumFeatures: "Premium Özellikler",
      dataServices: "Veri Hizmetleri",
      premiumReport: "Premium Detaylı Rapor Alın",
      premiumReportText: "Grafikler, rakip analizi ve gelir tahminleri ile 15+ sayfa",
      downloadPremiumReport: "Premium Raporu İndir ($5)",
      reAnalyze: "🔄 Yeniden Analiz Et",
      clear: "🗑️ Temizle",
      contactForAccess: "Erişim için info@trdefi.com ile iletişime geçin"
    },
    es: {
      businessAnalysis: "Análisis de Negocio",
      areaSelected: "Área Seleccionada",
      searchesUsed: "búsquedas utilizadas (se reinicia cada 15 días)",
      authRequired: "Autenticación Requerida",
      authRequiredText: "Por favor inicie sesión para acceder a las funciones de análisis de negocio",
      noAreaSelected: "Ningún Área Seleccionada",
      noAreaSelectedText: "Haga clic en \"Cómo Seleccionar Área\" para comenzar con su análisis de negocio",
      readyToAnalyze: "Listo para Analizar",
      readyToAnalyzeText: "Obtenga información empresarial integral impulsada por IA para su área seleccionada",
      searchLimitReached: "Límite de búsqueda alcanzado. Actualice para continuar analizando.",
      analyzeOpportunities: "Analizar Oportunidades de Negocio",
      analyzingLocation: "🔍 Analizando Ubicación",
      analyzingText: "Nuestra IA está procesando datos demográficos, tendencias de mercado y oportunidades de negocio...",
      analyzingSteps: [
        "• Analizando datos geográficos",
        "• Procesando tendencias del mercado",
        "• Identificando oportunidades"
      ],
      analysisResults: "Resultados del Análisis",
      premiumFeatures: "Características Premium",
      dataServices: "Servicios de Datos",
      premiumReport: "Obtener Reporte Premium Detallado",
      premiumReportText: "15+ páginas con gráficos, análisis de competidores y proyecciones de ingresos",
      downloadPremiumReport: "Descargar Reporte Premium ($5)",
      reAnalyze: "🔄 Re-analizar",
      clear: "🗑️ Limpiar",
      contactForAccess: "Contactar info@trdefi.com para acceso"
    },
    fr: {
      businessAnalysis: "Analyse d'Affaires",
      areaSelected: "Zone Sélectionnée",
      searchesUsed: "recherches utilisées (remise à zéro tous les 15 jours)",
      authRequired: "Authentification Requise",
      authRequiredText: "Veuillez vous connecter pour accéder aux fonctionnalités d'analyse d'affaires",
      noAreaSelected: "Aucune Zone Sélectionnée",
      noAreaSelectedText: "Cliquez sur \"Comment Sélectionner une Zone\" pour commencer votre analyse d'affaires",
      readyToAnalyze: "Prêt à Analyser",
      readyToAnalyzeText: "Obtenez des informations commerciales complètes alimentées par l'IA pour votre zone sélectionnée",
      searchLimitReached: "Limite de recherche atteinte. Mettez à niveau pour continuer à analyser.",
      analyzeOpportunities: "Analyser les Opportunités d'Affaires",
      analyzingLocation: "🔍 Analyse de l'Emplacement",
      analyzingText: "Notre IA traite les données démographiques, les tendances du marché et les opportunités d'affaires...",
      analyzingSteps: [
        "• Analyse des données géographiques",
        "• Traitement des tendances du marché",
        "• Identification des opportunités"
      ],
      analysisResults: "Résultats de l'Analyse",
      premiumFeatures: "Fonctionnalités Premium",
      dataServices: "Services de Données",
      premiumReport: "Obtenir un Rapport Premium Détaillé",
      premiumReportText: "15+ pages avec graphiques, analyse des concurrents et projections de revenus",
      downloadPremiumReport: "Télécharger le Rapport Premium ($5)",
      reAnalyze: "🔄 Re-analyser",
      clear: "🗑️ Effacer",
      contactForAccess: "Contacter info@trdefi.com pour l'accès"
    },
    nl: {
      businessAnalysis: "Bedrijfsanalyse",
      areaSelected: "Gebied Geselecteerd",
      searchesUsed: "zoekopdrachten gebruikt (wordt elke 15 dagen gereset)",
      authRequired: "Authenticatie Vereist",
      authRequiredText: "Log in om toegang te krijgen tot bedrijfsanalysefuncties",
      noAreaSelected: "Geen Gebied Geselecteerd",
      noAreaSelectedText: "Klik op \"Hoe Gebied Selecteren\" om te beginnen met uw bedrijfsanalyse",
      readyToAnalyze: "Klaar om te Analyseren",
      readyToAnalyzeText: "Krijg uitgebreide AI-gedreven bedrijfsinzichten voor uw geselecteerde gebied",
      searchLimitReached: "Zoeklimiet bereikt. Upgrade om door te gaan met analyseren.",
      analyzeOpportunities: "Zakelijke Kansen Analyseren",
      analyzingLocation: "🔍 Locatie Analyseren",
      analyzingText: "Onze AI verwerkt demografische gegevens, markttrends en zakelijke kansen...",
      analyzingSteps: [
        "• Geografische gegevens analyseren",
        "• Markttrends verwerken",
        "• Kansen identificeren"
      ],
      analysisResults: "Analyse Resultaten",
      premiumFeatures: "Premium Functies",
      dataServices: "Data Services",
      premiumReport: "Premium Gedetailleerd Rapport Krijgen",
      premiumReportText: "15+ pagina's met grafieken, concurrentieanalyse en omzetprognoses",
      downloadPremiumReport: "Premium Rapport Downloaden ($5)",
      reAnalyze: "🔄 Opnieuw Analyseren",
      clear: "🗑️ Wissen",
      contactForAccess: "Contact info@trdefi.com voor toegang"
    },
    ar: {
      businessAnalysis: "تحليل الأعمال",
      areaSelected: "تم اختيار المنطقة",
      searchesUsed: "عمليات بحث مستخدمة (يعيد التعيين كل 15 يومًا)",
      authRequired: "المصادقة مطلوبة",
      authRequiredText: "يرجى تسجيل الدخول للوصول إلى ميزات تحليل الأعمال",
      noAreaSelected: "لم يتم اختيار منطقة",
      noAreaSelectedText: "انقر على \"كيفية اختيار المنطقة\" للبدء في تحليل الأعمال",
      readyToAnalyze: "جاهز للتحليل",
      readyToAnalyzeText: "احصل على رؤى شاملة للأعمال مدعومة بالذكاء الاصطناعي للمنطقة المختارة",
      searchLimitReached: "تم الوصول لحد البحث. قم بالترقية للمتابعة.",
      analyzeOpportunities: "تحليل الفرص التجارية",
      analyzingLocation: "🔍 تحليل الموقع",
      analyzingText: "الذكاء الاصطناعي يعالج البيانات الديموغرافية واتجاهات السوق والفرص التجارية...",
      analyzingSteps: [
        "• تحليل البيانات الجغرافية",
        "• معالجة اتجاهات السوق",
        "• تحديد الفرص"
      ],
      analysisResults: "نتائج التحليل",
      premiumFeatures: "الميزات المميزة",
      dataServices: "خدمات البيانات",
      premiumReport: "احصل على تقرير مميز مفصل",
      premiumReportText: "15+ صفحة مع الرسوم البيانية وتحليل المنافسين وتوقعات الإيرادات",
      downloadPremiumReport: "تحميل التقرير المميز ($5)",
      reAnalyze: "🔄 إعادة التحليل",
      clear: "🗑️ مسح",
      contactForAccess: "تواصل مع info@trdefi.com للوصول"
    },
    he: {
      businessAnalysis: "ניתוח עסקי",
      areaSelected: "אזור נבחר",
      searchesUsed: "חיפושים בשימוש (מתאפס כל 15 יום)",
      authRequired: "נדרש אימות",
      authRequiredText: "אנא התחבר כדי לגשת לתכונות ניתוח עסקי",
      noAreaSelected: "לא נבחר אזור",
      noAreaSelectedText: "לחץ על \"איך לבחור אזור\" כדי להתחיל בניתוח העסקי שלך",
      readyToAnalyze: "מוכן לניתוח",
      readyToAnalyzeText: "קבל תובנות עסקיות מקיפות מבוססות AI עבור האזור שבחרת",
      searchLimitReached: "הגעת למגבלת החיפוש. שדרג כדי להמשיך לנתח.",
      analyzeOpportunities: "נתח הזדמנויות עסקיות",
      analyzingLocation: "🔍 מנתח מיקום",
      analyzingText: "הבינה המלאכותית שלנו מעבדת נתונים דמוגרפיים, מגמות שוק והזדמנויות עסקיות...",
      analyzingSteps: [
        "• מנתח נתונים גיאוגרפיים",
        "• מעבד מגמות שוק",
        "• מזהה הזדמנויות"
      ],
      analysisResults: "תוצאות הניתוח",
      premiumFeatures: "תכונות פרימיום",
      dataServices: "שירותי נתונים",
      premiumReport: "קבל דוח פרימיום מפורט",
      premiumReportText: "15+ עמודים עם תרשימים, ניתוח מתחרים ותחזיות הכנסות",
      downloadPremiumReport: "הורד דוח פרימיום ($5)",
      reAnalyze: "🔄 נתח מחדש",
      clear: "🗑️ נקה",
      contactForAccess: "צור קשר info@trdefi.com לגישה"
    }
  }

  const t = translations[selectedLanguage as keyof typeof translations] || translations.en

  const premiumFeatures = [
    { name: 'Competitor Analysis', price: '$3', description: 'Detailed competitor mapping and analysis' },
    { name: 'Market Size Calculator', price: '$2', description: 'Advanced market sizing models' },
    { name: 'Location Comparison', price: '$5', description: 'Side-by-side area comparison' },
    { name: 'Historical Trends', price: '$4', description: '5-year historical data analysis' },
    { name: 'Custom Branding', price: '$15/month', description: 'White-label reports with your brand' }
  ]

  const dataServices = [
    { name: 'Real Estate Insights', price: '$7', description: 'Property value and development potential' },
    { name: 'Demographic Deep Dive', price: '$6', description: 'Advanced population analytics' },
    { name: 'Traffic Pattern Analysis', price: '$8', description: 'Transportation and accessibility insights' }
  ]

  const canAnalyze = () => {
    if (!user) return false
    if (user.subscription !== 'free') return true
    
    const today = new Date().toDateString()
    const lastSearchDate = new Date(user.lastSearchDate).toDateString()
    
    return user.searchesUsed === 0 || lastSearchDate !== today
  }

  const getLanguagePrompt = (language: string) => {
    const languageMap: Record<string, string> = {
      'en': 'Please respond in English',
      'de': 'Bitte antworten Sie auf Deutsch',
      'tr': 'Lütfen Türkçe olarak yanıtlayın',
      'es': 'Por favor responda en español',
      'fr': 'Veuillez répondre en français',
      'nl': 'Gelieve te antwoorden in het Nederlands',
      'ar': 'يرجى الرد باللغة العربية',
      'he': 'אנא השב בעברית'
    }
    return languageMap[language] || 'Please respond in English'
  }

  const analyzeArea = async () => {
    if (!selectedArea) {
      toast.error('Please select an area on the map first')
      return
    }

    if (!canAnalyze()) {
      toast.error('You have reached your search limit. Please upgrade your plan.')
      return
    }

    console.log('Starting analysis for area:', selectedArea)
    setIsAnalyzing(true)
    setAnalysis(null)

    try {
      const languageInstruction = getLanguagePrompt(selectedLanguage)
      
      // Get section headers based on language
      const getSectionHeaders = (lang: string) => {
        const headers = {
          'en': {
            locationOverview: "🌍 **LOCATION OVERVIEW**",
            demographics: "👥 **DEMOGRAPHICS & TARGET MARKET**",
            businessLandscape: "🏢 **EXISTING BUSINESS LANDSCAPE**", 
            opportunities: "🚀 **TOP BUSINESS OPPORTUNITIES**",
            challenges: "⚠️ **POTENTIAL CHALLENGES**",
            marketSize: "💰 **MARKET SIZE ESTIMATION**",
            recommended: "🎯 **RECOMMENDED BUSINESS TYPES**",
            conclusion: "📊 **CONCLUSION & NEXT STEPS**"
          },
          'tr': {
            locationOverview: "🌍 **KONUM GEÇMİŞİ**",
            demographics: "👥 **DEMOGRAFİK VERİLER & HEDEF PAZAR**", 
            businessLandscape: "🏢 **MEVCUT İŞ ORTAMI**",
            opportunities: "🚀 **EN İYİ İŞ FIRSATLARI**",
            challenges: "⚠️ **POTANSIYEL ZORLUKLAR**",
            marketSize: "💰 **PAZAR BÜYÜKLÜĞÜ TAHMİNİ**",
            recommended: "🎯 **ÖNERİLEN İŞ TÜRLERİ**",
            conclusion: "📊 **SONUÇ VE SONRAKİ ADIMLAR**"
          },
          'de': {
            locationOverview: "🌍 **STANDORTÜBERSICHT**",
            demographics: "👥 **DEMOGRAFIE & ZIELMARKT**",
            businessLandscape: "🏢 **BESTEHENDE GESCHÄFTSLANDSCHAFT**",
            opportunities: "🚀 **TOP GESCHÄFTSMÖGLICHKEITEN**",
            challenges: "⚠️ **POTENZIELLE HERAUSFORDERUNGEN**",
            marketSize: "💰 **MARKTGRÖSSENSCHÄTZUNG**",
            recommended: "🎯 **EMPFOHLENE GESCHÄFTSARTEN**",
            conclusion: "📊 **FAZIT UND NÄCHSTE SCHRITTE**"
          },
          'es': {
            locationOverview: "🌍 **RESUMEN DE UBICACIÓN**",
            demographics: "👥 **DEMOGRAFÍA Y MERCADO OBJETIVO**",
            businessLandscape: "🏢 **PANORAMA EMPRESARIAL EXISTENTE**",
            opportunities: "🚀 **PRINCIPALES OPORTUNIDADES DE NEGOCIO**",
            challenges: "⚠️ **DESAFÍOS POTENCIALES**",
            marketSize: "💰 **ESTIMACIÓN DEL TAMAÑO DEL MERCADO**",
            recommended: "🎯 **TIPOS DE NEGOCIO RECOMENDADOS**",
            conclusion: "📊 **CONCLUSIÓN Y PRÓXIMOS PASOS**"
          },
          'fr': {
            locationOverview: "🌍 **APERÇU DE L'EMPLACEMENT**",
            demographics: "👥 **DÉMOGRAPHIE ET MARCHÉ CIBLE**",
            businessLandscape: "🏢 **PAYSAGE COMMERCIAL EXISTANT**",
            opportunities: "🚀 **PRINCIPALES OPPORTUNITÉS D'AFFAIRES**",
            challenges: "⚠️ **DÉFIS POTENTIELS**",
            marketSize: "💰 **ESTIMATION DE LA TAILLE DU MARCHÉ**",
            recommended: "🎯 **TYPES D'ENTREPRISES RECOMMANDÉS**",
            conclusion: "📊 **CONCLUSION ET PROCHAINES ÉTAPES**"
          },
          'nl': {
            locationOverview: "🌍 **LOCATIE OVERZICHT**",
            demographics: "👥 **DEMOGRAFIE & DOELMARKT**",
            businessLandscape: "🏢 **BESTAAND BEDRIJFSLANDSCHAP**",
            opportunities: "🚀 **TOP ZAKELIJKE KANSEN**",
            challenges: "⚠️ **POTENTIËLE UITDAGINGEN**",
            marketSize: "💰 **MARKTGROOTTE SCHATTING**",
            recommended: "🎯 **AANBEVOLEN BEDRIJFSTYPES**",
            conclusion: "📊 **CONCLUSIE EN VOLGENDE STAPPEN**"
          },
          'ar': {
            locationOverview: "🌍 **نظرة عامة على الموقع**",
            demographics: "👥 **الديموغرافيا والسوق المستهدف**",
            businessLandscape: "🏢 **المشهد التجاري الحالي**",
            opportunities: "🚀 **أفضل الفرص التجارية**",
            challenges: "⚠️ **التحديات المحتملة**",
            marketSize: "💰 **تقدير حجم السوق**",
            recommended: "🎯 **أنواع الأعمال الموصى بها**",
            conclusion: "📊 **الخلاصة والخطوات التالية**"
          },
          'he': {
            locationOverview: "🌍 **סקירת מיקום**",
            demographics: "👥 **דמוגרפיה ושוק יעד**",
            businessLandscape: "🏢 **נוף עסקי קיים**",
            opportunities: "🚀 **הזדמנויות עסקיות מובילות**",
            challenges: "⚠️ **אתגרים פוטנציאליים**",
            marketSize: "💰 **הערכת גודל שוק**",
            recommended: "🎯 **סוגי עסקים מומלצים**",
            conclusion: "📊 **מסקנה ושלבים הבאים**"
          }
        }
        return headers[lang] || headers['en']
      }

      const headers = getSectionHeaders(selectedLanguage)
      
      const prompt = `${languageInstruction}. 

Analyze the business opportunities for the geographic area with coordinates:
- North: ${selectedArea.bounds.north}
- South: ${selectedArea.bounds.south}  
- East: ${selectedArea.bounds.east}
- West: ${selectedArea.bounds.west}
- Center: ${selectedArea.center.lat}, ${selectedArea.center.lng}

Structure your response with these EXACT sections using emojis:

${headers.locationOverview}
(Describe the area type, urban/suburban classification, key landmarks)

${headers.demographics}
(Population characteristics, income levels, lifestyle preferences)

${headers.businessLandscape}
(Current businesses, competition density, market gaps)

${headers.opportunities}
(3 specific opportunities with reasoning)

${headers.challenges}
(Market risks, regulatory issues, competition threats)

${headers.marketSize}
(Revenue potential, customer base size, growth projections)

${headers.recommended}
(Specific business categories suited for this location)

${headers.conclusion}
(Summary and actionable recommendations)

Keep each section concise but informative. Use bullet points where appropriate.`

      const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash-exp:generateContent?key=AIzaSyApbwiPeQoZgSI8ZosfAhXq0Q6GpSaHlhs`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          contents: [{
            parts: [{
              text: prompt
            }]
          }],
          generationConfig: {
            temperature: 0.7,
            topK: 40,
            topP: 0.95,
            maxOutputTokens: 3000,
          }
        })
      })

      if (!response.ok) {
        throw new Error(`API request failed: ${response.status}`)
      }

      const data = await response.json()
      console.log('Gemini API response:', data)

      if (data.candidates && data.candidates[0] && data.candidates[0].content) {
        const analysisText = data.candidates[0].content.parts[0].text
        setAnalysis(analysisText)
        
        // Update user search count in Supabase
        if (user && user.subscription === 'free') {
          const { error } = await supabase
            .from('app_users')
            .update({
              searches_used: 1,
              last_search_date: new Date().toISOString()
            })
            .eq('id', user.id)
            
          if (error) {
            console.error('Error updating user search count:', error)
          }
        }
        
        toast.success('✅ Analysis complete!')
      } else {
        throw new Error('Invalid response format from API')
      }

    } catch (error) {
      console.error('Analysis error:', error)
      toast.error('❌ Failed to analyze area. Please try again.')
      setAnalysis('Sorry, there was an error analyzing this area. Please try again or select a different location.')
    } finally {
      setIsAnalyzing(false)
    }
  }

  const formatAnalysis = (text: string) => {
    const sections = text.split(/(?=🌍|👥|🏢|🚀|⚠️|💰|🎯|📊)/g).filter(section => section.trim())
    
    return sections.map((section, index) => {
      const trimmedSection = section.trim()
      if (!trimmedSection) return null

      const lines = trimmedSection.split('\n').filter(line => line.trim())
      const headerLine = lines[0]
      const contentLines = lines.slice(1)

      return (
        <div key={index} className="mb-6 last:mb-0">
          <div className="flex items-center gap-3 mb-3 p-3 bg-gradient-to-r from-blue-50 to-indigo-50 rounded-lg border-l-4 border-blue-500">
            <h3 className="font-bold text-lg text-gray-800">{headerLine}</h3>
          </div>
          <div className="pl-4 space-y-2">
            {contentLines.map((line, lineIndex) => (
              <p key={lineIndex} className="text-sm text-gray-700 leading-relaxed">
                {line.trim()}
              </p>
            ))}
          </div>
        </div>
      )
    }).filter(Boolean)
  }

  // Copy protection styles
  const copyProtectionStyles = {
    userSelect: 'none' as const,
    WebkitUserSelect: 'none' as const,
    MozUserSelect: 'none' as const,
    msUserSelect: 'none' as const,
    pointerEvents: 'none' as const,
    WebkitTouchCallout: 'none' as const,
    WebkitTapHighlightColor: 'transparent'
  }

  const handleWisePayment = () => {
    // Open Wise payment link in a new window
    const wisePaymentUrl = 'https://wise.com/pay/r/_J26rTIJ5o1NPL8'
    
    // Open payment window
    const paymentWindow = window.open(wisePaymentUrl, '_blank', 'width=800,height=600,scrollbars=yes,resizable=yes')
    
    if (paymentWindow) {
      toast.success('🔄 Payment window opened. After completing payment, return here to access your premium features.')
    } else {
      toast.error('❌ Unable to open payment window. Please disable popup blocker and try again.')
    }
  }

  return (
    <div className="h-full bg-gradient-to-b from-white to-gray-50 flex flex-col lg:w-96 border-l border-gray-200">
      {/* Header */}
      <div className="p-4 border-b border-gray-200 bg-gradient-to-r from-blue-600 to-indigo-600 text-white">
        <h2 className="text-xl font-bold flex items-center gap-2">
          <Zap className="w-6 h-6" />
          {t.businessAnalysis}
        </h2>
        {selectedArea && (
          <div className="mt-2 flex flex-wrap gap-1">
            <Badge variant="secondary" className="text-xs bg-white/20 text-white">
              {t.areaSelected}
            </Badge>
            <Badge variant="outline" className="text-xs border-white/30 text-white">
              {selectedArea.center.lat.toFixed(4)}, {selectedArea.center.lng.toFixed(4)}
            </Badge>
          </div>
        )}
        {user && user.subscription === 'free' && (
          <div className="mt-2 text-xs text-blue-100">
            {user.searchesUsed}/1 {t.searchesUsed}
          </div>
        )}
      </div>

      {/* Language Selector */}
      {selectedArea && user && (
        <div className="p-4 border-b border-gray-200 bg-gray-50">
          <LanguageSelector 
            selectedLanguage={selectedLanguage}
            onLanguageChange={onLanguageChange}
          />
        </div>
      )}

      {/* Content */}
      <div className="flex-1 overflow-y-auto">
        <div className="p-4 space-y-4">
          {!user && (
            <Card className="border-2 border-dashed border-orange-300 bg-gradient-to-r from-orange-50 to-yellow-50">
              <CardContent className="p-8 text-center">
                <Crown className="w-16 h-16 text-orange-500 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-orange-800 mb-2">{t.authRequired}</h3>
                <p className="text-sm text-orange-600">
                  {t.authRequiredText}
                </p>
              </CardContent>
            </Card>
          )}

          {user && !selectedArea && (
            <Card className="border-2 border-dashed border-gray-300">
              <CardContent className="p-8 text-center">
                <MapPin className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-gray-700 mb-2">{t.noAreaSelected}</h3>
                <p className="text-sm text-gray-500">
                  {t.noAreaSelectedText}
                </p>
              </CardContent>
            </Card>
          )}

          {user && selectedArea && !analysis && !isAnalyzing && (
            <Card className="border-2 border-blue-200 bg-gradient-to-br from-blue-50 to-indigo-50">
              <CardContent className="p-8">
                <div className="text-center mb-6">
                  <div className="w-20 h-20 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-full flex items-center justify-center mx-auto mb-4">
                    <TrendingUp className="w-10 h-10 text-white" />
                  </div>
                  <h3 className="text-xl font-bold text-gray-800 mb-2">{t.readyToAnalyze}</h3>
                  <p className="text-sm text-gray-600">
                    {t.readyToAnalyzeText}
                  </p>
                  {!canAnalyze() && (
                    <p className="text-xs text-red-600 mt-2">
                      {t.searchLimitReached}
                    </p>
                  )}
                </div>
                
                <Button 
                  onClick={analyzeArea} 
                  disabled={!canAnalyze()}
                  className="w-full bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 disabled:opacity-50"
                  size="lg"
                >
                  <Zap className="w-5 h-5 mr-2" />
                  {t.analyzeOpportunities}
                </Button>
              </CardContent>
            </Card>
          )}

          {isAnalyzing && (
            <Card className="border-2 border-yellow-200 bg-gradient-to-br from-yellow-50 to-orange-50">
              <CardContent className="p-8">
                <div className="text-center">
                  <div className="relative w-16 h-16 mx-auto mb-6">
                    <div className="w-16 h-16 border-4 border-yellow-200 border-t-yellow-500 rounded-full animate-spin"></div>
                    <div className="absolute inset-0 flex items-center justify-center">
                      <Globe className="w-6 h-6 text-yellow-600 animate-pulse" />
                    </div>
                  </div>
                  <h3 className="text-xl font-bold text-gray-800 mb-2">{t.analyzingLocation}</h3>
                  <p className="text-sm text-gray-600 mb-4">
                    {t.analyzingText}
                  </p>
                  <div className="text-xs text-gray-500 space-y-1">
                    {t.analyzingSteps.map((step, index) => (
                      <p key={index}>{step}</p>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {analysis && (
            <div className="space-y-6">
              <Card className="border-2 border-green-200 bg-gradient-to-br from-green-50 to-emerald-50">
                <CardHeader className="pb-4">
                  <CardTitle className="text-xl flex items-center gap-2 text-green-800">
                    <CheckCircle className="w-6 h-6" />
                    {t.analysisResults}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {/* Copy-protected analysis content */}
                  <div 
                    style={copyProtectionStyles}
                    className="select-none"
                    onContextMenu={(e) => e.preventDefault()}
                    onDragStart={(e) => e.preventDefault()}
                  >
                    <div className="space-y-6">
                      {formatAnalysis(analysis)}
                    </div>
                  </div>

                  <Separator className="my-6" />
                  
                  {/* Premium Features Dropdown */}
                  <Collapsible open={isPremiumFeaturesOpen} onOpenChange={setIsPremiumFeaturesOpen}>
                    <CollapsibleTrigger asChild>
                      <Button variant="outline" className="w-full justify-between mb-4">
                        <span className="flex items-center gap-2">
                          <Crown className="w-4 h-4 text-purple-600" />
                          {t.premiumFeatures}
                        </span>
                        <ChevronDown className="w-4 h-4" />
                      </Button>
                    </CollapsibleTrigger>
                    <CollapsibleContent className="space-y-2 mb-4">
                      {premiumFeatures.map((feature, index) => (
                        <div key={index} className="flex items-center justify-between p-3 bg-purple-50 rounded-lg border border-purple-200">
                          <div>
                            <p className="font-medium text-sm">{feature.name}</p>
                            <p className="text-xs text-gray-600">{feature.description}</p>
                          </div>
                          <div className="text-right">
                            <div className="text-xs text-purple-500">{t.contactForAccess}</div>
                          </div>
                        </div>
                      ))}
                    </CollapsibleContent>
                  </Collapsible>

                  {/* Data Services Dropdown */}
                  <Collapsible open={isDataServicesOpen} onOpenChange={setIsDataServicesOpen}>
                    <CollapsibleTrigger asChild>
                      <Button variant="outline" className="w-full justify-between mb-4">
                        <span className="flex items-center gap-2">
                          <Building className="w-4 h-4 text-blue-600" />
                          {t.dataServices}
                        </span>
                        <ChevronDown className="w-4 h-4" />
                      </Button>
                    </CollapsibleTrigger>
                    <CollapsibleContent className="space-y-2 mb-4">
                      {dataServices.map((service, index) => (
                        <div key={index} className="flex items-center justify-between p-3 bg-blue-50 rounded-lg border border-blue-200">
                          <div>
                            <p className="font-medium text-sm">{service.name}</p>
                            <p className="text-xs text-gray-600">{service.description}</p>
                          </div>
                          <div className="text-right">
                            <div className="text-xs text-blue-500">{t.contactForAccess}</div>
                          </div>
                        </div>
                      ))}
                    </CollapsibleContent>
                  </Collapsible>

                  {/* Premium Download Section */}
                  <div className="space-y-4">
                    <div className="text-center p-4 bg-gradient-to-r from-purple-100 to-blue-100 rounded-lg border-2 border-dashed border-purple-300">
                      <Lock className="w-8 h-8 text-purple-600 mx-auto mb-2" />
                      <h4 className="font-bold text-purple-800 mb-1">{t.premiumReport}</h4>
                      <p className="text-xs text-purple-600">
                        {t.premiumReportText}
                      </p>
                    </div>
                    
                    <Button 
                      onClick={handleWisePayment}
                      className="w-full bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
                    >
                      <ExternalLink className="w-4 h-4 mr-2" />
                      {t.downloadPremiumReport}
                    </Button>
                  </div>

                  <Separator className="my-4" />

                  <div className="flex gap-2">
                    <Button 
                      onClick={analyzeArea} 
                      disabled={!canAnalyze()}
                      variant="outline" 
                      size="sm"
                      className="flex-1"
                    >
                      {t.reAnalyze}
                    </Button>
                    <Button 
                      onClick={() => setAnalysis(null)} 
                      variant="ghost" 
                      size="sm"
                      className="flex-1"
                    >
                      {t.clear}
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

export default AnalysisPanel