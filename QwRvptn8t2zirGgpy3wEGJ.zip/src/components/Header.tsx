import { MapPin, Zap, Settings, LogOut, Mail, Shield, Users, Database } from 'lucide-react'
import { Button } from './ui/button'
import { Badge } from './ui/badge'
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator, DropdownMenuTrigger } from './ui/dropdown-menu'
import { Dialog, DialogContent, DialogHeader, DialogTitle } from './ui/dialog'
import { Card, CardContent, CardHeader, CardTitle } from './ui/card'
import { useState, useEffect } from 'react'
import { toast } from 'sonner'
import { useAuth } from '../hooks/useAuth'
import { supabase } from '../lib/supabase'

interface HeaderProps {
  onLogout?: () => void
  selectedLanguage: string
  onLanguageChange: (language: string) => void
}

const GeoScopeLogo = () => (
  <svg width="40" height="40" viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg">
    <circle cx="20" cy="20" r="18" fill="url(#gradient1)" stroke="#1e40af" strokeWidth="2"/>
    <circle cx="20" cy="20" r="12" fill="none" stroke="#ffffff" strokeWidth="2" opacity="0.8"/>
    <circle cx="20" cy="20" r="6" fill="none" stroke="#ffffff" strokeWidth="2" opacity="0.6"/>
    <rect x="18" y="8" width="4" height="24" fill="#ffffff" rx="2" opacity="0.9"/>
    <rect x="8" y="18" width="24" height="4" fill="#ffffff" rx="2" opacity="0.9"/>
    <circle cx="20" cy="20" r="3" fill="#fbbf24"/>
    <defs>
      <linearGradient id="gradient1" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#3b82f6"/>
        <stop offset="50%" stopColor="#1d4ed8"/>
        <stop offset="100%" stopColor="#1e3a8a"/>
      </linearGradient>
    </defs>
  </svg>
)

interface AppUser {
  id: string
  email: string
  subscription: string
  searches_used: number
  last_search_date: string
  created_at: string
}

const AdminPanel = () => {
  const [users, setUsers] = useState<AppUser[]>([])
  const [loading, setLoading] = useState(true)
  const [stats, setStats] = useState({
    totalUsers: 0,
    freeUsers: 0,
    premiumUsers: 0,
    totalSearches: 0
  })

  useEffect(() => {
    fetchUsers()
  }, [])

  const fetchUsers = async () => {
    try {
      const { data, error } = await supabase
        .from('app_users')
        .select('*')
        .order('created_at', { ascending: false })

      if (error) throw error

      setUsers(data || [])
      
      // Calculate stats
      const totalUsers = data?.length || 0
      const freeUsers = data?.filter(u => u.subscription === 'free').length || 0
      const premiumUsers = totalUsers - freeUsers
      const totalSearches = data?.reduce((sum, u) => sum + u.searches_used, 0) || 0

      setStats({
        totalUsers,
        freeUsers,
        premiumUsers,
        totalSearches
      })
    } catch (error) {
      console.error('Error fetching users:', error)
      toast.error('Failed to load user data')
    } finally {
      setLoading(false)
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center p-8">
        <div className="w-8 h-8 border-4 border-blue-600 border-t-transparent rounded-full animate-spin"></div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Stats Cards */}
      <div className="grid grid-cols-2 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm flex items-center gap-2">
              <Users className="w-4 h-4" />
              Total Users
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold text-blue-600">{stats.totalUsers}</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm flex items-center gap-2">
              <Zap className="w-4 h-4" />
              Total Searches
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold text-green-600">{stats.totalSearches}</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm">Free Users</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold text-gray-600">{stats.freeUsers}</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm">Premium Users</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold text-purple-600">{stats.premiumUsers}</p>
          </CardContent>
        </Card>
      </div>

      {/* Users List */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Database className="w-5 h-5 text-blue-600" />
            User Database (Supabase)
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3 max-h-96 overflow-y-auto">
            {users.map((user) => (
              <div key={user.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <div>
                  <p className="font-medium text-sm">{user.email}</p>
                  <p className="text-xs text-gray-500">
                    Joined: {new Date(user.created_at).toLocaleDateString()}
                  </p>
                  <p className="text-xs text-gray-500">
                    Last search: {new Date(user.last_search_date).toLocaleDateString()}
                  </p>
                </div>
                <div className="text-right">
                  <Badge className={`text-xs mb-1 ${
                    user.subscription === 'enterprise' ? 'bg-purple-100 text-purple-800' :
                    user.subscription === 'pro' ? 'bg-blue-100 text-blue-800' :
                    user.subscription === 'basic' ? 'bg-green-100 text-green-800' :
                    'bg-gray-100 text-gray-800'
                  }`}>
                    {user.subscription.toUpperCase()}
                  </Badge>
                  <p className="text-xs text-gray-500">{user.searches_used} searches</p>
                </div>
              </div>
            ))}
            {users.length === 0 && (
              <p className="text-center text-gray-500 py-8">No users found</p>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

const SubscriptionPlans = ({ selectedLanguage }: { selectedLanguage: string }) => {
  const translations = {
    en: {
      basicPlan: "Basic Plan",
      proPlan: "Pro Plan",
      enterprise: "Enterprise",
      unlimitedSearches: "• Unlimited searches",
      basicAnalysis: "• Basic business analysis",
      standardSupport: "• Standard support",
      upgradeToBasic: "Upgrade to Basic",
      monthlyAnalyses: "• 30 analyses per month",
      premiumFeatures: "• Premium features included",
      prioritySupport: "• Priority support",
      advancedAnalytics: "• Advanced analytics",
      upgradeToPro: "Upgrade to Pro",
      unlimitedEverything: "• Unlimited everything",
      customIntegrations: "• Custom integrations",
      dedicatedSupport: "• Dedicated support",
      whiteLabelOptions: "• White-label options",
      contactCustom: "Contact for Custom Configuration"
    },
    de: {
      basicPlan: "Basic Plan",
      proPlan: "Pro Plan",
      enterprise: "Enterprise",
      unlimitedSearches: "• Unbegrenzte Suchen",
      basicAnalysis: "• Grundlegende Geschäftsanalyse",
      standardSupport: "• Standard Support",
      upgradeToBasic: "Auf Basic upgraden",
      monthlyAnalyses: "• 30 Analysen pro Monat",
      premiumFeatures: "• Premium-Funktionen enthalten",
      prioritySupport: "• Priority Support",
      advancedAnalytics: "• Erweiterte Analytik",
      upgradeToPro: "Auf Pro upgraden",
      unlimitedEverything: "• Unbegrenzt alles",
      customIntegrations: "• Benutzerdefinierte Integrationen",
      dedicatedSupport: "• Dedizierter Support",
      whiteLabelOptions: "• White-Label-Optionen",
      contactCustom: "Kontakt für individuelle Konfiguration"
    },
    tr: {
      basicPlan: "Temel Plan",
      proPlan: "Pro Plan",
      enterprise: "Kurumsal",
      unlimitedSearches: "• Sınırsız arama",
      basicAnalysis: "• Temel iş analizi",
      standardSupport: "• Standart destek",
      upgradeToBasic: "Temel'e Yükselt",
      monthlyAnalyses: "• Ayda 30 analiz",
      premiumFeatures: "• Premium özellikler dahil",
      prioritySupport: "• Öncelikli destek",
      advancedAnalytics: "• Gelişmiş analitik",
      upgradeToPro: "Pro'ya Yükselt",
      unlimitedEverything: "• Her şey sınırsız",
      customIntegrations: "• Özel entegrasyonlar",
      dedicatedSupport: "• Özel destek",
      whiteLabelOptions: "• Beyaz etiket seçenekleri",
      contactCustom: "Özel Konfigürasyon İçin İletişime Geçin"
    }
  }

  const t = translations[selectedLanguage as keyof typeof translations] || translations.en

  return (
    <div className="space-y-4">
      <div className="grid gap-4">
        <Card className="border-2 border-green-200">
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <span>{t.basicPlan}</span>
              <span className="text-green-600 font-bold">$9/month</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2 text-sm">
              <li>{t.unlimitedSearches}</li>
              <li>{t.basicAnalysis}</li>
              <li>{t.standardSupport}</li>
            </ul>
            <Button className="w-full mt-4 bg-green-600 hover:bg-green-700">
              {t.upgradeToBasic}
            </Button>
          </CardContent>
        </Card>
        
        <Card className="border-2 border-blue-200">
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <span>{t.proPlan}</span>
              <span className="text-blue-600 font-bold">$29/month</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2 text-sm">
              <li>{t.monthlyAnalyses}</li>
              <li>{t.premiumFeatures}</li>
              <li>{t.prioritySupport}</li>
              <li>{t.advancedAnalytics}</li>
            </ul>
            <Button className="w-full mt-4 bg-blue-600 hover:bg-blue-700">
              {t.upgradeToPro}
            </Button>
          </CardContent>
        </Card>
        
        <Card className="border-2 border-purple-200">
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <span>{t.enterprise}</span>
              <span className="text-purple-600 font-bold">Custom</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2 text-sm">
              <li>{t.unlimitedEverything}</li>
              <li>{t.customIntegrations}</li>
              <li>{t.dedicatedSupport}</li>
              <li>{t.whiteLabelOptions}</li>
            </ul>
            <Button className="w-full mt-4 bg-purple-600 hover:bg-purple-700">
              {t.contactCustom}
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

const Header = ({ onLogout, selectedLanguage, onLanguageChange }: HeaderProps) => {
  const [showAdminPanel, setShowAdminPanel] = useState(false)
  const [showSubscriptionPlans, setShowSubscriptionPlans] = useState(false)
  const { user, signOut } = useAuth()
  
  console.log('Header component rendered with user:', user)

  const isAdmin = user?.email === 'cem@trdefi.com'

  const getSubscriptionColor = (subscription: string) => {
    switch (subscription) {
      case 'basic': return 'bg-green-100 text-green-800'
      case 'pro': return 'bg-blue-100 text-blue-800'
      case 'enterprise': return 'bg-purple-100 text-purple-800'
      default: return 'bg-gray-100 text-gray-800'
    }
  }

  const handleLogout = async () => {
    try {
      await signOut()
      if (onLogout) onLogout()
      toast.success('Logged out successfully')
    } catch (error) {
      toast.error('Logout failed')
    }
  }

  const translations = {
    en: {
      subscriptionPlans: "Subscription Plans",
      signOut: "Sign Out",
      contact: "Contact (info@trdefi.com)",
      adminDashboard: "Admin Dashboard"
    },
    de: {
      subscriptionPlans: "Abonnement-Pläne",
      signOut: "Abmelden",
      contact: "Kontakt (info@trdefi.com)",
      adminDashboard: "Admin Dashboard"
    },
    tr: {
      subscriptionPlans: "Abonelik Planları",
      signOut: "Çıkış Yap",
      contact: "İletişim (info@trdefi.com)",
      adminDashboard: "Yönetici Paneli"
    }
  }

  const t = translations[selectedLanguage as keyof typeof translations] || translations.en

  return (
    <>
      <header className="h-16 bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 border-b border-blue-700 px-6 flex items-center justify-between shadow-lg">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-3">
            <GeoScopeLogo />
            <div>
              <h1 className="text-xl font-bold text-white">GeoScope</h1>
              <p className="text-sm text-blue-100">Business Analyzer</p>
            </div>
          </div>
        </div>
        
        <div className="flex items-center gap-4">
          {user && (
            <div className="flex items-center gap-3">
              {isAdmin && (
                <Button 
                  variant="ghost" 
                  size="sm" 
                  className="text-white hover:bg-white/10"
                  onClick={() => setShowAdminPanel(true)}
                >
                  <Shield className="w-4 h-4 mr-2" />
                  {t.adminDashboard}
                </Button>
              )}
              
              <Badge className={`text-xs font-medium ${getSubscriptionColor(user.subscription)}`}>
                {user.subscription.toUpperCase()}
              </Badge>
              
              <div className="text-white text-sm">
                <span className="font-medium">{user.email}</span>
                {user.subscription === 'free' && (
                  <div className="text-xs text-blue-200">
                    {user.searchesUsed}/1 searches used
                  </div>
                )}
              </div>
              
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="sm" className="text-white hover:bg-white/10">
                    <Settings className="w-4 h-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-56">
                  <DropdownMenuItem onClick={() => setShowSubscriptionPlans(true)}>
                    <Zap className="w-4 h-4 mr-2" />
                    {t.subscriptionPlans}
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={handleLogout}>
                    <LogOut className="w-4 h-4 mr-2" />
                    {t.signOut}
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={() => window.location.href = 'mailto:info@trdefi.com'}>
                    <Mail className="w-4 h-4 mr-2" />
                    {t.contact}
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          )}
          
          <div className="flex items-center gap-2 text-sm text-blue-100">
            <Zap className="w-4 h-4" />
            <span>Powered by Gemini AI</span>
          </div>
        </div>
      </header>

      {/* Admin Panel Modal */}
      <Dialog open={showAdminPanel} onOpenChange={setShowAdminPanel}>
        <DialogContent className="sm:max-w-4xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Shield className="w-5 h-5 text-blue-600" />
              {t.adminDashboard}
            </DialogTitle>
          </DialogHeader>
          <AdminPanel />
        </DialogContent>
      </Dialog>

      {/* Subscription Plans Modal */}
      <Dialog open={showSubscriptionPlans} onOpenChange={setShowSubscriptionPlans}>
        <DialogContent className="sm:max-w-2xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Zap className="w-5 h-5 text-purple-600" />
              {t.subscriptionPlans}
            </DialogTitle>
          </DialogHeader>
          <SubscriptionPlans selectedLanguage={selectedLanguage} />
        </DialogContent>
      </Dialog>
    </>
  )
}

export default Header